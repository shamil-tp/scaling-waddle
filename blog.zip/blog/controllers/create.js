
exports.Post=((req,res)=>{
    return res.render('create')
})