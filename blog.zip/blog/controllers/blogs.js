
exports.Blogs=((req,res)=>{
    return res.render('blogs')
})