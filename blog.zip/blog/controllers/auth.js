
exports.getLoginPage=((req,res)=>{
    return res.render('login')
})
exports.getSignupPage=((req,res)=>{
    return res.render('signup')
})
exports.Login=((req,res)=>{
    console.log(req.body)
})
// exports.Testt=((req,res)=>{
//     return res.sen
// })