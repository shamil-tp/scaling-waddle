const mongoose = require('mongoose')


exports.connectDB=()=>{
    mongoose.connect('mongodb+srv://shamil:urcx5298@mysnapgram.zq2yd.mongodb.net/blog').then(()=>console.log('connected to database')).catch((e)=>console.log("DB failed",e));
}