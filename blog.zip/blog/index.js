const express = require('express')
const app = express()

app.set('view engine','ejs')
app.use(express.static('./static'))
app.use(express.urlencoded({extended:true}))

const {getLoginPage,Login}=require('./controllers/auth')
const {Blogs}=require('./controllers/blogs')
const {Post}=require('./controllers/create')
const {connectDB}=require('./databse/connect')
connectDB()

app.get('/login',getLoginPage)
app.post('/login',Login)
app.get('/blogs',Blogs)
app.get('/post',Post)
//app.get('/testt',Test)

app.listen(8000,()=>{console.log('app started')})